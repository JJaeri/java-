package com.test.type.b.test02;

    public class Game369Test {
    public static void main(String[] args) {
 
       
        int num = 0;
        switch (num) {
		case 81:
			
			break;
			
		case 0:
			
			System.out.println("�ڼ� %��");
			num++;
			
			break;

		default:
			break;
		}
        
        
    }
}

